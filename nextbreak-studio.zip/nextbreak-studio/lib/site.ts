// Central site configuration. Update these values before launch.
export const site = {
  name: "Next Break Studio",
  tagline: "Software built with purpose.",
  description:
    "Next Break Studio is an independent software studio that builds and operates its own digital products designed to solve practical problems.",
  // TODO(before launch): confirm the domain you register and a working inbox.
  url: "https://nextbreakstudio.com",
  email: "hello@nextbreakstudio.com",
  lastUpdated: "October 27, 2026",
};

export const products = [
  {
    slug: "uppeak",
    name: "UpPeak",
    status: "In development",
    summary:
      "Website monitoring and analysis. UpPeak is being built to examine individual pages, surface findings, and recommend practical fixes.",
    // TODO(before launch): confirm the final UpPeak domain.
    url: "https://uppeak.com",
  },
] as const;

export const nav = [
  { href: "/products", label: "Products" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
] as const;
