import Link from "next/link";
import { ArrowRight, ArrowUpRight, Layers, Mail, Wrench, Workflow } from "lucide-react";
import { Container } from "@/components/Container";
import { Button } from "@/components/Button";
import { StatusBadge } from "@/components/StatusBadge";
import { ProductMockup } from "@/components/ProductMockup";
import { products, site } from "@/lib/site";

const principles = [
  {
    icon: Layers,
    title: "Solve meaningful problems.",
    body: "Start from a real, practical need and build only what addresses it.",
  },
  {
    icon: Wrench,
    title: "Build useful, reliable software.",
    body: "Favor dependable systems and sensible engineering over novelty.",
  },
  {
    icon: Workflow,
    title: "Make complex work simpler.",
    body: "Use thoughtful automation to remove effort, not to add noise.",
  },
];

export default function HomePage() {
  const uppeak = products[0];

  return (
    <>
      {/* 2. Hero */}
      <section className="border-b border-line">
        <Container className="py-24 sm:py-36">
          <p className="text-xs font-medium uppercase tracking-[0.18em] text-silver">
            Independent software studio
          </p>
          <h1 className="mt-6 max-w-4xl text-5xl font-semibold leading-[1.04] tracking-tight sm:text-7xl lg:text-8xl">
            {site.tagline}
          </h1>
          <p className="mt-8 max-w-2xl text-base leading-relaxed text-silver sm:text-lg">
            We build independent digital products designed to solve practical
            problems through thoughtful engineering and useful automation.
          </p>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <Button href="/products">
              Explore our products <ArrowRight size={16} aria-hidden="true" />
            </Button>
            <Button href="/about" variant="secondary">
              About the studio
            </Button>
          </div>
        </Container>
      </section>

      {/* 3. Philosophy */}
      <section className="border-b border-line" aria-labelledby="philosophy">
        <Container className="py-20 sm:py-28">
          <h2 id="philosophy" className="text-xs font-medium uppercase tracking-[0.18em] text-silver">
            Philosophy
          </h2>
          <ul className="mt-10 grid gap-4 md:grid-cols-3">
            {principles.map(({ icon: Icon, title, body }) => (
              <li key={title} className="rounded-2xl border border-line bg-charcoal p-6 sm:p-8">
                <Icon size={20} className="text-silver" aria-hidden="true" />
                <h3 className="mt-6 text-lg font-medium tracking-tight">{title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-silver">{body}</p>
              </li>
            ))}
          </ul>
        </Container>
      </section>

      {/* 4. Featured product */}
      <section className="border-b border-line" aria-labelledby="featured">
        <Container className="py-20 sm:py-28">
          <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
            <div>
              <p className="text-xs font-medium uppercase tracking-[0.18em] text-silver">
                Featured product
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-4">
                <h2 id="featured" className="text-4xl font-semibold tracking-tight sm:text-5xl">
                  {uppeak.name}
                </h2>
                <StatusBadge>{uppeak.status}</StatusBadge>
              </div>
              <p className="mt-6 max-w-lg text-base leading-relaxed text-silver sm:text-lg">
                {uppeak.summary}
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row">
                <Button href={uppeak.url} external>
                  Visit UpPeak <ArrowUpRight size={16} aria-hidden="true" />
                </Button>
                <Button href="/products" variant="secondary">
                  All products
                </Button>
              </div>
            </div>
            <ProductMockup />
          </div>
        </Container>
      </section>

      {/* 5. About */}
      <section className="border-b border-line" aria-labelledby="about-studio">
        <Container className="py-20 sm:py-28">
          <div className="grid gap-8 lg:grid-cols-[1fr_2fr] lg:gap-16">
            <h2 id="about-studio" className="text-xs font-medium uppercase tracking-[0.18em] text-silver">
              About the studio
            </h2>
            <div>
              <p className="max-w-2xl text-2xl font-medium leading-snug tracking-tight sm:text-3xl">
                Next Break Studio exists to build and operate its own digital
                products, each focused on a practical problem.
              </p>
              <Link
                href="/about"
                className="mt-8 inline-flex items-center gap-2 text-sm text-offwhite underline decoration-silver/40 underline-offset-4 transition-colors hover:decoration-offwhite"
              >
                Read more about the studio <ArrowRight size={14} aria-hidden="true" />
              </Link>
            </div>
          </div>
        </Container>
      </section>

      {/* 6. Contact */}
      <section aria-labelledby="contact-cta">
        <Container className="py-20 sm:py-28">
          <h2 id="contact-cta" className="max-w-2xl text-3xl font-semibold tracking-tight sm:text-5xl">
            Have a business inquiry?
          </h2>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-silver sm:text-lg">
            We would be glad to hear from you. Send us a note and we will reply
            as soon as we can.
          </p>
          <div className="mt-8">
            <Button href={`mailto:${site.email}`}>
              <Mail size={16} aria-hidden="true" /> {site.email}
            </Button>
          </div>
        </Container>
      </section>
    </>
  );
}
