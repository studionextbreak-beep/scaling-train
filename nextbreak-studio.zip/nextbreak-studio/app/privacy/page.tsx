import type { Metadata } from "next";
import { Container } from "@/components/Container";
import { PageHeading } from "@/components/PageHeading";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How the Next Break Studio website handles information.",
  openGraph: { title: "Privacy Policy | Next Break Studio", url: "/privacy" },
};

export default function PrivacyPage() {
  return (
    <>
      <PageHeading eyebrow="Legal" title="Privacy Policy">
        <p>Last updated: {site.lastUpdated}</p>
      </PageHeading>
      <section>
        <Container className="py-16 sm:py-24">
          <div className="max-w-2xl space-y-8 text-base leading-relaxed text-silver">
            <div>
              <h2 className="text-lg font-medium text-offwhite">What this site collects</h2>
              <p className="mt-3">
                This website is a static informational site. It has no user
                accounts, no forms that store data, and no database. We do not
                intentionally collect personal information through it.
              </p>
            </div>
            <div>
              <h2 className="text-lg font-medium text-offwhite">Hosting data</h2>
              <p className="mt-3">
                The site is hosted on Vercel. Like most hosts, Vercel may
                process technical data such as IP addresses and request logs to
                deliver and secure the site. See Vercel&apos;s own privacy
                policy for details.
              </p>
            </div>
            <div>
              <h2 className="text-lg font-medium text-offwhite">Email</h2>
              <p className="mt-3">
                If you email us at{" "}
                <a className="text-offwhite underline underline-offset-4" href={`mailto:${site.email}`}>
                  {site.email}
                </a>
                , we will use your message and address only to respond to you.
              </p>
            </div>
            <div>
              <h2 className="text-lg font-medium text-offwhite">Analytics and cookies</h2>
              <p className="mt-3">
                This site does not currently use advertising cookies or
                analytics. If that changes, this page will be updated.
              </p>
            </div>
            <p className="text-sm text-silver/70">
              This policy describes the site&apos;s current practices and has not
              been reviewed by a lawyer.
            </p>
          </div>
        </Container>
      </section>
    </>
  );
}
