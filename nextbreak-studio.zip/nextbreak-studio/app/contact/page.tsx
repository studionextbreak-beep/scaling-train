import type { Metadata } from "next";
import { Mail } from "lucide-react";
import { Container } from "@/components/Container";
import { PageHeading } from "@/components/PageHeading";
import { Button } from "@/components/Button";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with Next Break Studio for business inquiries.",
  openGraph: { title: "Contact | Next Break Studio", url: "/contact" },
};

export default function ContactPage() {
  return (
    <>
      <PageHeading eyebrow="Contact" title="Business inquiries.">
        <p>
          The best way to reach us is by email. We read every message and reply
          as soon as we can.
        </p>
      </PageHeading>

      <section>
        <Container className="py-16 sm:py-24">
          <div className="max-w-xl rounded-2xl border border-line bg-charcoal p-6 sm:p-10">
            <Mail size={22} className="text-silver" aria-hidden="true" />
            <p className="mt-6 text-sm text-silver">Email</p>
            <a
              href={`mailto:${site.email}`}
              className="mt-1 block break-all text-xl font-medium tracking-tight text-offwhite underline decoration-silver/40 underline-offset-4 transition-colors hover:decoration-offwhite sm:text-2xl"
            >
              {site.email}
            </a>
            <div className="mt-8">
              <Button href={`mailto:${site.email}`}>Send an email</Button>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
