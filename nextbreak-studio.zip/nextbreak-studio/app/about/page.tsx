import type { Metadata } from "next";
import { Container } from "@/components/Container";
import { PageHeading } from "@/components/PageHeading";
import { Button } from "@/components/Button";

export const metadata: Metadata = {
  title: "About",
  description:
    "Next Break Studio is an independent software studio building its own digital products. Read our mission and principles.",
  openGraph: { title: "About | Next Break Studio", url: "/about" },
};

const principles = [
  {
    title: "Product-first",
    body: "We show what we build rather than making vague promises.",
  },
  {
    title: "Understated confidence",
    body: "Strong typography and thoughtful spacing instead of flashy effects.",
  },
  {
    title: "Honest progress",
    body: "Products that are in development are clearly labeled as such.",
  },
  {
    title: "Built to scale",
    body: "New products can be introduced without changing the overall structure.",
  },
  {
    title: "Automation-minded",
    body: "We favor useful systems and practical solutions over technology for its own sake.",
  },
];

export default function AboutPage() {
  return (
    <>
      <PageHeading eyebrow="About" title="An independent software studio.">
        <p>
          Next Break Studio builds independent digital products designed to
          solve practical problems.
        </p>
      </PageHeading>

      <section className="border-b border-line">
        <Container className="grid gap-8 py-16 sm:py-24 lg:grid-cols-[1fr_2fr] lg:gap-16">
          <h2 className="text-xs font-medium uppercase tracking-[0.18em] text-silver">
            What we build
          </h2>
          <div className="max-w-2xl space-y-5 text-base leading-relaxed text-silver sm:text-lg">
            <p>
              The studio creates and operates its own digital products. Every
              product has its own website, identity, and experience, while this
              site acts as the central home of the studio.
            </p>
            <p>
              Our first product, UpPeak, is a website monitoring and analysis
              tool currently in development.
            </p>
          </div>
        </Container>
      </section>

      <section className="border-b border-line">
        <Container className="py-16 sm:py-24">
          <h2 className="text-xs font-medium uppercase tracking-[0.18em] text-silver">
            Principles
          </h2>
          <ul className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {principles.map((p) => (
              <li key={p.title} className="rounded-2xl border border-line bg-charcoal p-6">
                <h3 className="text-lg font-medium tracking-tight">{p.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-silver">{p.body}</p>
              </li>
            ))}
          </ul>
        </Container>
      </section>

      <section>
        <Container className="py-16 sm:py-24">
          <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">
            Want to get in touch?
          </h2>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button href="/contact">Contact the studio</Button>
            <Button href="/products" variant="secondary">
              View products
            </Button>
          </div>
        </Container>
      </section>
    </>
  );
}
