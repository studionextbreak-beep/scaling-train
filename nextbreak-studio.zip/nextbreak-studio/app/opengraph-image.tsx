import { ImageResponse } from "next/og";

export const alt = "Next Break Studio — Software built with purpose.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          background: "#090a0c",
          color: "#f4f5f6",
          padding: 80,
        }}
      >
        <div style={{ fontSize: 34, color: "#a7adb7" }}>Next Break Studio</div>
        <div style={{ fontSize: 96, fontWeight: 600, lineHeight: 1.05 }}>
          Software built with purpose.
        </div>
      </div>
    ),
    size,
  );
}
