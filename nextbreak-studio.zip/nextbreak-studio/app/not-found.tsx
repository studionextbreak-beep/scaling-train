import { Container } from "@/components/Container";
import { Button } from "@/components/Button";

export default function NotFound() {
  return (
    <Container className="py-32 sm:py-44">
      <p className="text-xs font-medium uppercase tracking-[0.18em] text-silver">404</p>
      <h1 className="mt-5 text-4xl font-semibold tracking-tight sm:text-6xl">
        Page not found.
      </h1>
      <p className="mt-6 max-w-md text-base leading-relaxed text-silver">
        The page you are looking for does not exist or has moved.
      </p>
      <div className="mt-10">
        <Button href="/">Back to home</Button>
      </div>
    </Container>
  );
}
