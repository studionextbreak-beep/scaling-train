import type { Metadata } from "next";
import { ArrowUpRight } from "lucide-react";
import { Container } from "@/components/Container";
import { PageHeading } from "@/components/PageHeading";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/Button";
import { products } from "@/lib/site";

export const metadata: Metadata = {
  title: "Products",
  description:
    "The products built and operated by Next Break Studio, with their current status.",
  openGraph: { title: "Products | Next Break Studio", url: "/products" },
};

export default function ProductsPage() {
  return (
    <>
      <PageHeading eyebrow="Products" title="What we are building.">
        <p>
          Each product has its own website and experience. Status is shown
          honestly for every one.
        </p>
      </PageHeading>

      <section>
        <Container className="py-16 sm:py-24">
          <ul className="grid gap-4">
            {products.map((p) => (
              <li
                key={p.slug}
                className="rounded-2xl border border-line bg-charcoal p-6 sm:p-10"
              >
                <div className="flex flex-wrap items-center gap-4">
                  <h2 className="text-3xl font-semibold tracking-tight">{p.name}</h2>
                  <StatusBadge>{p.status}</StatusBadge>
                </div>
                <p className="mt-5 max-w-2xl text-base leading-relaxed text-silver">
                  {p.summary}
                </p>
                <div className="mt-8">
                  <Button href={p.url} external variant="secondary">
                    Visit {p.name} <ArrowUpRight size={16} aria-hidden="true" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </Container>
      </section>
    </>
  );
}
