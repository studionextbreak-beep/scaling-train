import type { Metadata } from "next";
import { Container } from "@/components/Container";
import { PageHeading } from "@/components/PageHeading";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "Terms",
  description: "Terms for using the Next Break Studio website.",
  openGraph: { title: "Terms | Next Break Studio", url: "/terms" },
};

export default function TermsPage() {
  return (
    <>
      <PageHeading eyebrow="Legal" title="Terms">
        <p>Last updated: {site.lastUpdated}</p>
      </PageHeading>
      <section>
        <Container className="py-16 sm:py-24">
          <div className="max-w-2xl space-y-8 text-base leading-relaxed text-silver">
            <div>
              <h2 className="text-lg font-medium text-offwhite">Using this site</h2>
              <p className="mt-3">
                This website provides information about Next Break Studio and
                its products. By using it you agree to use it lawfully and not
                to interfere with its operation.
              </p>
            </div>
            <div>
              <h2 className="text-lg font-medium text-offwhite">Product status</h2>
              <p className="mt-3">
                Products described here may be in development. Descriptions
                reflect current plans and may change. Nothing on this site is a
                guarantee of features, availability, or timing.
              </p>
            </div>
            <div>
              <h2 className="text-lg font-medium text-offwhite">Intellectual property</h2>
              <p className="mt-3">
                The content, name, and design of this site belong to Next Break
                Studio unless stated otherwise.
              </p>
            </div>
            <div>
              <h2 className="text-lg font-medium text-offwhite">Liability</h2>
              <p className="mt-3">
                The site is provided as is. To the extent permitted by law, we
                are not liable for losses arising from its use.
              </p>
            </div>
            <div>
              <h2 className="text-lg font-medium text-offwhite">Contact</h2>
              <p className="mt-3">
                Questions about these terms:{" "}
                <a className="text-offwhite underline underline-offset-4" href={`mailto:${site.email}`}>
                  {site.email}
                </a>
                .
              </p>
            </div>
            <p className="text-sm text-silver/70">
              These terms describe the site&apos;s current use and have not been
              reviewed by a lawyer.
            </p>
          </div>
        </Container>
      </section>
    </>
  );
}
