export function StatusBadge({ children }: { children: string }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-line px-3 py-1 text-xs text-silver">
      <span className="h-1.5 w-1.5 rounded-full bg-silver" aria-hidden="true" />
      {children}
    </span>
  );
}
