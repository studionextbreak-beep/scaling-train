import { FileSearch, ListChecks, Wrench } from "lucide-react";

// A clearly labeled concept mockup. It contains no real data or metrics.
export function ProductMockup() {
  const rows = [
    { icon: FileSearch, label: "Page analysis", note: "Examine each page individually" },
    { icon: ListChecks, label: "Findings", note: "Clear, prioritized issues" },
    { icon: Wrench, label: "Recommended fixes", note: "Practical next steps" },
  ];
  return (
    <figure>
      <div
        role="img"
        aria-label="Concept mockup of the UpPeak interface showing page analysis, findings, and recommended fixes"
        className="overflow-hidden rounded-2xl border border-line bg-charcoal"
      >
        <div className="flex items-center gap-2 border-b border-line px-4 py-3">
          <span className="h-2.5 w-2.5 rounded-full bg-silver/30" />
          <span className="h-2.5 w-2.5 rounded-full bg-silver/30" />
          <span className="h-2.5 w-2.5 rounded-full bg-silver/30" />
          <span className="ml-3 text-xs text-silver">UpPeak</span>
        </div>
        <div className="space-y-3 p-4 sm:p-6">
          {rows.map(({ icon: Icon, label, note }) => (
            <div
              key={label}
              className="flex items-center gap-4 rounded-xl border border-line bg-obsidian/60 p-4"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-line text-offwhite">
                <Icon size={18} aria-hidden="true" />
              </span>
              <div>
                <p className="text-sm font-medium text-offwhite">{label}</p>
                <p className="text-xs text-silver">{note}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <figcaption className="mt-3 text-xs text-silver/70">
        Concept mockup. Not a screenshot of the finished product.
      </figcaption>
    </figure>
  );
}
