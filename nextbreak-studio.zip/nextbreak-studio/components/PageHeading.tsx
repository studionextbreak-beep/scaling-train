import type { ReactNode } from "react";
import { Container } from "./Container";

export function PageHeading({
  eyebrow,
  title,
  children,
}: {
  eyebrow: string;
  title: string;
  children?: ReactNode;
}) {
  return (
    <section className="border-b border-line">
      <Container className="py-20 sm:py-28">
        <p className="text-xs font-medium uppercase tracking-[0.18em] text-silver">
          {eyebrow}
        </p>
        <h1 className="mt-5 max-w-3xl text-4xl font-semibold leading-[1.08] tracking-tight sm:text-6xl">
          {title}
        </h1>
        {children ? (
          <div className="mt-6 max-w-2xl text-base leading-relaxed text-silver sm:text-lg">
            {children}
          </div>
        ) : null}
      </Container>
    </section>
  );
}
