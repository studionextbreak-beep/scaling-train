import Link from "next/link";
import { Container } from "./Container";
import { nav, site } from "@/lib/site";

export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-obsidian/80 backdrop-blur-md">
      <Container className="flex h-16 items-center justify-between">
        <Link
          href="/"
          className="text-[15px] font-semibold tracking-tight text-offwhite"
          aria-label={`${site.name} home`}
        >
          Next Break <span className="font-normal text-silver">Studio</span>
        </Link>

        <nav aria-label="Primary" className="flex items-center gap-1 sm:gap-2">
          {nav.map((item) =>
            item.href === "/contact" ? (
              <Link
                key={item.href}
                href={item.href}
                className="ml-1 rounded-full border border-line px-4 py-2 text-sm text-offwhite transition-colors duration-200 hover:border-silver/50 hover:bg-charcoal"
              >
                {item.label}
              </Link>
            ) : (
              <Link
                key={item.href}
                href={item.href}
                className="rounded-full px-3 py-2 text-sm text-silver transition-colors duration-200 hover:text-offwhite sm:px-4"
              >
                {item.label}
              </Link>
            ),
          )}
        </nav>
      </Container>
    </header>
  );
}
