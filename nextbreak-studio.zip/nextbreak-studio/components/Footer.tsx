import Link from "next/link";
import { Container } from "./Container";
import { nav, site } from "@/lib/site";

export function Footer() {
  return (
    <footer className="border-t border-line">
      <Container className="py-12">
        <div className="flex flex-col gap-10 sm:flex-row sm:justify-between">
          <div className="max-w-xs">
            <p className="text-[15px] font-semibold tracking-tight">
              Next Break <span className="font-normal text-silver">Studio</span>
            </p>
            <p className="mt-3 text-sm leading-relaxed text-silver">
              {site.tagline}
            </p>
          </div>

          <div className="flex gap-16">
            <nav aria-label="Footer">
              <ul className="space-y-3 text-sm">
                {nav.map((item) => (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className="text-silver transition-colors hover:text-offwhite"
                    >
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
            <nav aria-label="Legal">
              <ul className="space-y-3 text-sm">
                <li>
                  <Link
                    href="/privacy"
                    className="text-silver transition-colors hover:text-offwhite"
                  >
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link
                    href="/terms"
                    className="text-silver transition-colors hover:text-offwhite"
                  >
                    Terms
                  </Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>

        <p className="mt-12 text-xs text-silver/70">
          © {new Date().getFullYear()} {site.name}. All rights reserved.
        </p>
      </Container>
    </footer>
  );
}
