import Link from "next/link";
import type { ReactNode } from "react";

type Props = {
  href: string;
  children: ReactNode;
  variant?: "primary" | "secondary";
  external?: boolean;
  className?: string;
};

const base =
  "inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-medium transition-colors duration-200 sm:w-auto";

const variants = {
  primary: "bg-offwhite text-obsidian hover:bg-white",
  secondary:
    "border border-line text-offwhite hover:border-silver/50 hover:bg-charcoal",
};

export function Button({
  href,
  children,
  variant = "primary",
  external = false,
  className = "",
}: Props) {
  const cls = `${base} ${variants[variant]} ${className}`;
  if (external) {
    return (
      <a href={href} className={cls} target="_blank" rel="noopener noreferrer">
        {children}
      </a>
    );
  }
  return (
    <Link href={href} className={cls}>
      {children}
    </Link>
  );
}
